# vvce_mar25
This repo was created for the c and python competitive training of 6 days delivered in the month of march 2025 in  vvce
