# mtd_c_py
This repo was created to learn and understand c and python programming trained by MTD in the month of March 2025
